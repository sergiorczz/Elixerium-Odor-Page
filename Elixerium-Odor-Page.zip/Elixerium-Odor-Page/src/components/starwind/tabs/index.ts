import Tabs from "./Tabs.astro";
import TabsContent from "./TabsContent.astro";
import TabsList from "./TabsList.astro";
import TabsTrigger from "./TabsTrigger.astro";
import { tabs, tabsContent, tabsList, tabsTrigger } from "./variants";

const TabsVariants = {
  tabs,
  tabsContent,
  tabsList,
  tabsTrigger,
};

const TabsParts = {
  Root: Tabs,
  List: TabsList,
  Trigger: TabsTrigger,
  Content: TabsContent,
};

export { Tabs, TabsContent, TabsList, TabsTrigger, TabsVariants };

export default TabsParts;
