import InputOtp from "./InputOtp.astro";
import InputOtpGroup from "./InputOtpGroup.astro";
import InputOtpSeparator from "./InputOtpSeparator.astro";
import InputOtpSlot from "./InputOtpSlot.astro";
import { inputOtp, inputOtpGroup, inputOtpSeparator, inputOtpSlot } from "./variants";

const REGEXP_ONLY_DIGITS = /^[0-9]+$/;
const REGEXP_ONLY_DIGITS_AND_CHARS = /^[A-Za-z0-9]+$/;

const InputOtpVariants = {
  inputOtp,
  inputOtpGroup,
  inputOtpSeparator,
  inputOtpSlot,
};

const InputOtpParts = {
  Root: InputOtp,
  Group: InputOtpGroup,
  Separator: InputOtpSeparator,
  Slot: InputOtpSlot,
};

export {
  InputOtp,
  InputOtpGroup,
  InputOtpSeparator,
  InputOtpSlot,
  InputOtpVariants,
  REGEXP_ONLY_DIGITS,
  REGEXP_ONLY_DIGITS_AND_CHARS,
};

export default InputOtpParts;
